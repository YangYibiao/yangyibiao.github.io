#define s (((((((((((((((( 0
#define _ * 2)
#define X * 2 + 1)
static unsigned short stopwatch[] = {
 s _ _ _ _ _ X X X X X _ _ _ X X _ ,
 s _ _ _ X X X X X X X X X _ X X X ,
 s _ _ X X X _ _ _ _ _ X X X _ X X ,
 s _ X X _ _ _ _ _ _ _ _ _ X X _ _ ,
 s X X _ _ _ _ _ _ _ _ _ _ _ X X _ ,
 s X X _ X X X X X _ _ _ _ _ X X _ ,
 s X X _ _ _ _ _ X _ _ _ _ _ X X _ ,
 s X X _ _ _ _ _ X _ _ _ _ _ X X _ ,
 s _ X X _ _ _ _ X _ _ _ _ X X _ _ ,
 s _ _ X X X _ _ _ _ _ X X X _ _ _ ,
 s _ _ _ X X X X X X X X X _ _ _ _ ,
 s _ _ _ _ _ X X X X X _ _ _ _ _ _ , };