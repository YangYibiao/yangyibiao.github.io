#include <stdio.h>

int main(void) {
  printf("Hello, NJU!");
  return 0;
}