
INPUT: data from the "input" folder
OUTPUT: stored in the "output" folder

working directory is "script_r" folder. This "script_r" folder consists of R scripts and README.txt that explains how to run R scripts.
